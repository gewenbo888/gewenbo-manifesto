# CBT Daily Thought Journal Template (Obsidian & Notion Ready)

> Copy this template into your Obsidian Vault or Notion Workspace for your daily psychological resilience practice.

---

### Date: {{date}}
### Time: {{time}}
### Energy Level (1-10): 
### Overall Mood: [ ] Calm  [ ] Anxious  [ ] Fatigued  [ ] Focused  [ ] Overwhelmed

---

## 1. Acute Trigger / Situation
- **Trigger event**: 
- **Time and Location**: 
- **Who was involved**: 

## 2. Automatic Negative Thoughts (ANTs)
- *What specific thoughts ran through my mind?*
- *What am I predicting will happen?*

## 3. Emotional State
- **Primary Emotion**: (Anxiety / Fear / Anger / Shame / Sadness)
- **Initial Intensity**: [ ] % (0 - 100)
- **Physical Sensations**: (Tight chest / Shallow breath / Clenched jaw / Stomach knot)

## 4. Cognitive Distortions Identified
- [ ] **Catastrophizing** (Predicting the worst possible outcome)
- [ ] **All-or-Nothing** (Black and white, perfection or failure)
- [ ] **Mind Reading** (Assuming others judge me negatively)
- [ ] **Emotional Reasoning** (I feel it, therefore it must be true)
- [ ] **Fortune Telling** (Treating gloomy predictions as facts)
- [ ] **Should Statements** (Unrealistic self-demands causing guilt)
- [ ] **Mental Filtering** (Dwelling exclusively on the single negative)

## 5. Evidence Examination
- **Facts that support the thought**:
  1. 
  2. 
- **Facts that CONTRADICT the thought**:
  1. 
  2. 
  3. 

## 6. Rational Alternative Reframe
> *"What is a compassionate, realistic, and objective perspective on this situation?"*
- **Reframe**: 

## 7. Re-rated Emotion & Micro-Action
- **Re-rated Intensity**: [ ] % (0 - 100)
- **Relief Achieved**: - [ ] %
- **Next Smallest Physical Action**: (e.g., drink water, 3-minute stretch, complete 1 task)
  - [ ] Action completed
