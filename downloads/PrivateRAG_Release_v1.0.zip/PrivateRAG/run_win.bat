@echo off
echo Starting PrivateRAG 100% Local Knowledge Vault...
python -m pip install -q streamlit pypdf sentence-transformers
python app.py
pause
