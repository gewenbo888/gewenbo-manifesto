# PrivateRAG: 100% Offline Document Chat & Local Knowledge Base

## Overview
PrivateRAG is an enterprise-grade, offline-first local RAG (Retrieval-Augmented Generation) toolkit designed for professionals (lawyers, doctors, financial analysts, developers) who require absolute data privacy.

- **100% Offline**: Runs entirely on your local machine. Zero telemetry, zero cloud data transfer.
- **Zero API Costs**: Compatible with local Ollama, LM Studio, or local quantized models (GGUF).
- **Universal Ingestion**: Drag and drop PDF, DOCX, TXT, Markdown, and Code files.
- **Instant Hybrid Search**: BM25 keyword matching + Vector Cosine Similarity for pinpoint factual citations.

## Quickstart
- **macOS / Linux**: Run `./run_mac.sh`
- **Windows**: Double click `run_win.bat`
- Open browser at `http://localhost:8501` to start chatting with your private documents!

---
© 2026 Wenbo Ge (TrustlessX). Lifetime personal license included.
