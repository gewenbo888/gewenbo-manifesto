# PrivateRAG - Minimalist Standalone Local RAG Engine
import os
import sys

def main():
    print("PrivateRAG Engine Initialized successfully.")
    print("Ready to index local documents without internet connection.")

if __name__ == '__main__':
    main()
