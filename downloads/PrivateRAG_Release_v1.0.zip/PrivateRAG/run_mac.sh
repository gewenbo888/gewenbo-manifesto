#!/usr/bin/env bash
echo "Starting PrivateRAG 100% Local Knowledge Vault..."
python3 -m pip install -q streamlit pypdf sentence-transformers 2>/dev/null || true
python3 app.py
