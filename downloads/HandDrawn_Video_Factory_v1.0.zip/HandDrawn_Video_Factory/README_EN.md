# HandDrawn Video Factory: 1-Click Minimalist Explanatory Video Engine

## Overview
HandDrawn Video Factory is a deterministic, audio-first video production pipeline designed to generate viral, high-retention explanatory short videos in the iconic BoomEarth / KaterJ style.

- **Pure White Canvas**: #FFFFFF background, clean relaxed black ink lines with generous negative space.
- **Physical Metaphors**: Replaces boring abstract diagrams with vivid physical actions (breaking barriers, pulling levers, turning gears).
- **Audio-First Alignment**: Microsoft Edge-TTS voiceover with word-level timestamp alignment.
- **Centered Big Subtitles**: High-contrast, clean 16:9 widescreen or 9:16 vertical ASS subtitles.
- **1-Click FFmpeg Render**: Fast, deterministic local rendering without GPU bloat.

## What's Included:
1. `generator.py`: Complete Python script for script parsing, audio generation, and video compilation.
2. `prompt_templates.json`: 100+ proven BoomEarth / KaterJ style visual prompts for technology, finance, philosophy, and cognitive science.
3. `render_video.sh`: 1-click execution script.

---
© 2026 Wenbo Ge (TrustlessX). Commercial license included.
