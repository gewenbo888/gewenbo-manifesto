#!/bin/bash
cd "$(dirname "$0")"

echo "========================================================"
echo "  Whisper 离线音视频字幕提取器 · Mac 一键启动"
echo "========================================================"
echo ""

if ! command -v python3 &> /dev/null; then
    echo "[错误] 未检测到 python3，请先安装 Python 3.10+。"
    read -p "按回车退出..."
    exit 1
fi

if ! python3 -m pip show openai-whisper &> /dev/null; then
    echo "首次运行正在安装依赖（国内清华源加速，仅需一次）..."
    python3 -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
fi

echo "正在启动图形界面..."
python3 whisper_gui.py
