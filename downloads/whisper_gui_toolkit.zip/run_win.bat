@echo off
chcp 65001 >nul
title Whisper 离线智能字幕提取器
echo ========================================================
echo   Whisper 离线音视频字幕提取器 · 纯本地免配置运行环境
echo ========================================================
echo.
cd /d %~dp0

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 检测到系统未安装 Python 环境！
    echo 请先前往 python.org 安装 Python 3.10 或更高版本（安装时请勾选 Add Python to PATH）。
    pause
    exit /b
)

echo [1/2] 正在检查并准备本地 Whisper 运行依赖...
pip show openai-whisper >nul 2>&1
if %errorlevel% neq 0 (
    echo 首次运行正在安装基础依赖，请保持网络畅通（仅需一次，国内镜像加速中）...
    pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
)

echo [2/2] 启动极客图形化界面...
python whisper_gui.py

pause
