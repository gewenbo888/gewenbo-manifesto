#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Whisper 离线音视频无损提取字幕 GUI 工具箱 · 极客纯离线版
出品：现实主权数字资产 · 纯本地运行 · 零泄密 · 不限时长
"""

import sys
import os
import subprocess
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

class WhisperGUIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Whisper 离线智能音视频字幕提取器 · 永久单机版")
        self.root.geometry("680x560")
        self.root.configure(bg="#0b1329")
        self.is_running = False

        # 头部标题
        header_frame = tk.Frame(root, bg="#0b1329")
        header_frame.pack(fill="x", pady=(15, 5))
        
        lbl_title = tk.Label(
            header_frame, 
            text="⚡ Whisper 离线音视频转文字/字幕工具箱", 
            font=("Helvetica", 16, "bold"), 
            fg="#38bdf8", 
            bg="#0b1329"
        )
        lbl_title.pack()

        lbl_desc = tk.Label(
            header_frame, 
            text="100% 纯本地离线运行 · 绝不上云 · 涉密录音零泄密 · 不按分钟扣费", 
            font=("Helvetica", 9), 
            fg="#94a3b8", 
            bg="#0b1329"
        )
        lbl_desc.pack(pady=2)

        # 文件选择区域
        file_box = tk.LabelFrame(root, text=" 1. 选择待转换音视频源文件 ", fg="#38bdf8", bg="#111c38", font=("Helvetica", 10, "bold"), padx=10, pady=10)
        file_box.pack(fill="x", padx=25, pady=8)

        self.file_path_var = tk.StringVar(value="尚未选择音视频文件...")
        lbl_file = tk.Label(
            file_box, 
            textvariable=self.file_path_var, 
            fg="#e2e8f0", 
            bg="#1e293b", 
            anchor="w", 
            padx=10, 
            relief="flat", 
            font=("Helvetica", 9)
        )
        lbl_file.pack(side="left", fill="x", expand=True, ipady=6)

        btn_browse = tk.Button(
            file_box, 
            text="📁 浏览文件", 
            command=self.browse_file, 
            bg="#0284c7", 
            fg="white", 
            font=("Helvetica", 9, "bold"),
            padx=15, 
            relief="flat",
            cursor="hand2"
        )
        btn_browse.pack(side="right", padx=(8, 0))

        # 参数配置区域
        cfg_box = tk.LabelFrame(root, text=" 2. 转换参数设置 ", fg="#38bdf8", bg="#111c38", font=("Helvetica", 10, "bold"), padx=10, pady=10)
        cfg_box.pack(fill="x", padx=25, pady=8)

        # 模型选择
        tk.Label(cfg_box, text="模型大小:", fg="#cbd5e1", bg="#111c38", font=("Helvetica", 9)).grid(row=0, column=0, sticky="w", pady=4)
        self.model_combo = ttk.Combobox(
            cfg_box, 
            values=["base (速度快/资源低-推荐)", "tiny (极速尝鲜)", "small (平衡高准度)", "medium (专业高精)", "large-v3 (极致出版级)"],
            state="readonly",
            width=22
        )
        self.model_combo.current(0)
        self.model_combo.grid(row=0, column=1, sticky="w", padx=(5, 20), pady=4)

        # 语言选择
        tk.Label(cfg_box, text="音频语种:", fg="#cbd5e1", bg="#111c38", font=("Helvetica", 9)).grid(row=0, column=2, sticky="w", pady=4)
        self.lang_combo = ttk.Combobox(
            cfg_box, 
            values=["自动识别 (Auto)", "中文普通话 (zh)", "英语 (en)", "粤语 (yue)", "日语 (ja)", "韩语 (ko)"],
            state="readonly",
            width=16
        )
        self.lang_combo.current(0)
        self.lang_combo.grid(row=0, column=3, sticky="w", padx=(5, 0), pady=4)

        # 输出格式
        tk.Label(cfg_box, text="导出格式:", fg="#cbd5e1", bg="#111c38", font=("Helvetica", 9)).grid(row=1, column=0, sticky="w", pady=4)
        self.format_combo = ttk.Combobox(
            cfg_box, 
            values=["SRT (剪映/PR标准字幕)", "TXT (纯文本纪要)", "VTT (网页字幕)", "all (全部格式导出)"],
            state="readonly",
            width=22
        )
        self.format_combo.current(0)
        self.format_combo.grid(row=1, column=1, sticky="w", padx=(5, 20), pady=4)

        # 控制与执行按钮
        btn_frame = tk.Frame(root, bg="#0b1329")
        btn_frame.pack(fill="x", padx=25, pady=6)

        self.btn_run = tk.Button(
            btn_frame, 
            text="🚀 开始本地极速提取字幕", 
            command=self.start_transcribe_thread, 
            bg="#10b981", 
            fg="white", 
            font=("Helvetica", 11, "bold"), 
            pady=6, 
            relief="flat",
            cursor="hand2"
        )
        self.btn_run.pack(side="left", fill="x", expand=True, padx=(0, 5))

        self.btn_open_dir = tk.Button(
            btn_frame, 
            text="📂 打开输出目录", 
            command=self.open_output_dir, 
            bg="#475569", 
            fg="white", 
            font=("Helvetica", 9), 
            pady=6, 
            padx=12,
            relief="flat",
            cursor="hand2"
        )
        self.btn_open_dir.pack(side="right")

        # 实时终端日志输出窗口
        log_box = tk.LabelFrame(root, text=" 3. 运行日志与进度 ", fg="#38bdf8", bg="#111c38", font=("Helvetica", 10, "bold"), padx=10, pady=8)
        log_box.pack(fill="both", expand=True, padx=25, pady=(4, 10))

        self.log_text = tk.Text(log_box, bg="#080c16", fg="#22c55e", font=("Courier", 9), insertbackground="white", relief="flat")
        self.log_text.pack(fill="both", expand=True)

        # 底部状态栏
        self.status_var = tk.StringVar(value="准备就绪 · 本地免配置环境已激活")
        lbl_status = tk.Label(root, textvariable=self.status_var, fg="#64748b", bg="#0b1329", font=("Helvetica", 8))
        lbl_status.pack(side="bottom", pady=4)

        self.log("=== Whisper 本地离线字幕提取器就绪 ===")
        self.log("提示：首次使用某个模型时，系统会自动下载对应的离线权重，后续纯断网可用。")

    def log(self, msg):
        self.log_text.insert("end", msg + "\n")
        self.log_text.see("end")

    def browse_file(self):
        f = filedialog.askopenfilename(
            title="选择要提取字幕的音视频文件",
            filetypes=[
                ("所有音视频媒体", "*.mp4 *.mov *.mkv *.mp3 *.wav *.m4a *.aac *.flac *.wma"),
                ("视频文件", "*.mp4 *.mov *.mkv"),
                ("音频文件", "*.mp3 *.wav *.m4a *.aac *.flac")
            ]
        )
        if f:
            self.file_path_var.set(f)
            self.log(f"已选择源文件: {os.path.basename(f)}")

    def open_output_dir(self):
        p = self.file_path_var.get()
        if p and os.path.exists(p):
            d = os.path.dirname(p)
        else:
            d = os.getcwd()
        if sys.platform == "darwin":
            subprocess.run(["open", d])
        elif sys.platform == "win32":
            os.startfile(d)
        else:
            subprocess.run(["xdg-open", d])

    def get_selected_model(self):
        val = self.model_combo.get().split()[0]
        return val

    def get_selected_format(self):
        val = self.format_combo.get().split()[0].lower()
        return val

    def get_selected_lang(self):
        val = self.lang_combo.get()
        if "zh" in val: return "zh"
        if "en" in val: return "en"
        if "yue" in val: return "yue"
        if "ja" in val: return "ja"
        if "ko" in val: return "ko"
        return None

    def start_transcribe_thread(self):
        if self.is_running:
            messagebox.showwarning("提示", "当前已有任务正在提取中，请耐心等待！")
            return
        
        filepath = self.file_path_var.get()
        if not filepath or not os.path.exists(filepath):
            messagebox.showwarning("提示", "请先点击【浏览文件】选择有效的音视频文件！")
            return

        self.is_running = True
        self.btn_run.config(state="disabled", text="⏳ 正在离线提取中，请勿关闭窗口...")
        self.status_var.set("正在本地调用 Whisper 引擎进行智能语音转写...")

        t = threading.Thread(target=self._do_transcribe, args=(filepath,), daemon=True)
        t.start()

    def _do_transcribe(self, filepath):
        try:
            model_name = self.get_selected_model()
            out_format = self.get_selected_format()
            lang = self.get_selected_lang()
            out_dir = os.path.dirname(filepath)

            self.log("\n-------------------------------------------")
            self.log(f"🚀 开始执行本地离线转换任务:")
            self.log(f"源文件: {os.path.basename(filepath)}")
            self.log(f"选用模型: {model_name}")
            self.log(f"导出格式: {out_format}")
            if lang:
                self.log(f"指定语种: {lang}")
            self.log("正在加载本地引擎与模型权重...")

            # 优先尝试使用 whisper 命令行 CLI (标准且稳定)
            cmd = [
                sys.executable, "-m", "whisper",
                filepath,
                "--model", model_name,
                "--output_dir", out_dir
            ]
            if out_format != "all":
                cmd.extend(["--output_format", out_format])
            if lang:
                cmd.extend(["--language", lang])

            self.log(f"运行命令: {' '.join(cmd)}")
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace"
            )

            for line in proc.stdout:
                line_str = line.strip()
                if line_str:
                    self.log(line_str)

            proc.wait()

            if proc.returncode == 0:
                self.log("\n✅ 恭喜！离线字幕提取圆满成功！")
                self.log(f"结果已保存在: {out_dir}")
                self.status_var.set("转换成功！文件已生成在源文件同级目录下。")
                messagebox.showinfo("提取完成", f"恭喜！字幕提取已成功完成！\n\n文件已生成并保存在源文件同级目录下。\n点击【打开输出目录】即可查看！")
            else:
                self.log(f"\n⚠️ 提取过程报错，退出代码: {proc.returncode}")
                self.status_var.set("转换失败，请检查上方日志详情。")
                messagebox.showerror("运行异常", "提取过程出现异常，请检查日志。若首次运行，可能缺少 openai-whisper 依赖，请运行脚本安装。")

        except Exception as e:
            self.log(f"异常错误: {str(e)}")
            messagebox.showerror("系统错误", f"发生未捕获异常: {str(e)}")
        finally:
            self.is_running = False
            self.btn_run.config(state="normal", text="🚀 开始本地极速提取字幕")

if __name__ == '__main__':
    root = tk.Tk()
    app = WhisperGUIApp(root)
    root.mainloop()
