# SoloFoundry: Production-Ready MCP Suite & Agentic Workflow for Claude & Cursor

## Overview
SoloFoundry provides 8 battle-tested Model Context Protocol (MCP) servers and full-stack agent harnesses, turning Claude Desktop and Cursor into an autonomous "One-Person Software Factory".

## Included 8 Core MCP Servers
1. `filesystem_sandbox`: Secure restricted workspace file operations.
2. `browser_controller`: Headless Chromium web interaction, form filling, scraping.
3. `sqlite_analyst`: Zero-setup local relational data persistence and queries.
4. `terminal_guard`: Sandboxed shell execution with safety policy filtering.
5. `github_automator`: Issue tracking, PR reviews, branch operations.
6. `markdown_extractor`: Clean text extraction from web pages and documents.
7. `memory_vault`: Persistent cross-session vector & keyword memory.
8. `crypto_signer`: Local Web3 signing and balance checks for sovereign transactions.

## Installation
Copy `claude_desktop_config.json` to your Claude Desktop directory or import `cursor_settings_template.json` into Cursor.

---
© 2026 Wenbo Ge (TrustlessX). MIT License for bundled servers.
