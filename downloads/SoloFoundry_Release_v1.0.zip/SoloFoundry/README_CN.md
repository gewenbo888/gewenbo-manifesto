# SoloFoundry: 生产级 MCP 工具箱与一人公司全栈工作流

## 产品概述
SoloFoundry 专为 Cursor / Claude Code / Windsurf 重度用户打造，提供 8 大工业级 Model Context Protocol (MCP) 服务与智能体配置母板，让 AI 真正拥有“系统的手与眼”。

## 8 大核心本地 MCP 服务
1. `filesystem_sandbox`: 安全工作区受限文件读写与代码分析
2. `browser_controller`: 无头浏览器自动交互、表单提交与数据抓取
3. `sqlite_analyst`: 本地零配置 SQLite 数据库分析与持久化
4. `terminal_guard`: 带命令过滤与风险拦截的安全终端调用器
5. `github_automator`: GitHub Issue 追踪、PR 自动生成与代码审查
6. `markdown_extractor`: 网页与复杂格式文档高信噪比清洗器
7. `memory_vault`: 跨会话向量记忆与上下文持久化存储
8. `crypto_signer`: 本地 Web3 签名与主权链上支付验证

## 即开即用
直接导入 `cursor_settings_template.json` 或覆盖 `claude_desktop_config.json`，即可一键点亮全套能力！
