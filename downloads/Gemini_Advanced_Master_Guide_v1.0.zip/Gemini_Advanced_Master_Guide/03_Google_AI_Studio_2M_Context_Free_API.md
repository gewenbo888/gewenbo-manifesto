# 03. Google AI Studio 200万上下文免费额度全解
- 访问 https://aistudio.google.com/
- 点击 'Get API key' 创建专属 API 密钥；
- 免费版层级支持 Gemini 1.5 Pro / 2.0 Flash，单次请求最大支持 2,000,000 Token 上下文；
- 在开源客户端（Cherry Studio / NextChat / Chatbox）中填入 API Key 与代理端点，即可 0 费用畅享顶级智能体。
