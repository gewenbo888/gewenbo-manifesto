# Gemini Advanced & 2M Context AI Studio Master Guide

## Overview
This complete master guide provides step-by-step instructions to unlock Google's flagship Gemini 1.5/2.0 Pro models with the industry-exclusive 2,000,000 token context window at a fraction of standard costs (or 100% free via official developer tiers).

## Included Modules:
1. `01_India_Regional_Pricing_Setup.md`: Step-by-step regional subscription setup using legitimate payment methods.
2. `02_Google_One_Family_Plan_Hack.md`: How to split Google One AI Premium across 5 family members (reducing monthly cost to ~$0.70/mo per person).
3. `03_Google_AI_Studio_2M_Context_Free_API.md`: How to get official free API keys with 2M context and connect them directly to Cherry Studio, NextChat, or Chatbox without monthly fees.
4. `04_Anti_Ban_And_Tax_Free_Zipcodes.md`: Critical guidelines on avoiding account flags, tax-free billing addresses, and payment verification bypass.
5. `05_Gemini_Deep_Research_Prompt_Vault.json`: 50+ battle-tested prompts for deep academic research, long-book synthesis, and complex code refactoring.

---
© 2026 Wenbo Ge (TrustlessX). For personal educational use.
