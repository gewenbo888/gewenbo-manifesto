# 02. Google One 5人家庭组拼车降本方案
- 主账号开通 Google One 2TB AI Premium 后，在 families.google.com 创建家庭组；
- 发送邀请给 5 个家庭成员账号（所有成员的 Google Play 地区必须保持一致）；
- 5 个成员均可独立享受 2TB 共享空间与 Gemini Advanced 网页端/App 端特权；
- 人均月成本从 140 元直接降至 3~5 元。
